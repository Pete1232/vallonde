var assets = document.createElement('script');
assets.type = 'text/javascript';
assets.src = config["assets-uri"];
document.getElementsByTagName('head')[0].appendChild(assets);
