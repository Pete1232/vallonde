var config = {
    "api-base-url": "../../../test/assets",
    "assets-uri": "../../assets/js/update_character.js"
};
